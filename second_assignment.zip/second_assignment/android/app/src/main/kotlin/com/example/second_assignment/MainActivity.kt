package com.example.second_assignment

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()

import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'dart:convert';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
     
      debugShowCheckedModeBanner: false,
      home: Todo(),
    );
  }
}

class Todo extends StatefulWidget {
  @override
  _TodoState createState() => _TodoState();
}

class _TodoState extends State<Todo> {
  List<Map<String, dynamic>> tasks = [];
  final TextEditingController taskController = TextEditingController();

  @override
  void initState() {
    super.initState();
    loadTasks();
  }

  // Load tasks from SharedPreferences
  Future<void> loadTasks() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    String? tasksString = prefs.getString('tasks');
    if (tasksString != null) {


      // List<dynamic> taskList = jsonDecode(tasksString);
      setState(() {
  



        // tasks = taskList.map((task) => Map<String, dynamic>.from(task)).toList();
      });
    }
  }

 
  Future<void> saveTasks() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    await prefs.setString('tasks', jsonEncode(tasks));
  }

  void addTask() {
    if (taskController.text.isNotEmpty) {
      setState(() {
        tasks.add({'task': taskController.text, 'isCompleted': false});
        taskController.clear();
      });
      saveTasks();
    }
  }

  void toggleTaskCompletion(int index) {
    setState(() {
      tasks[index]['isCompleted'] = !tasks[index]['isCompleted'];
    });
    saveTasks();
  }

  void updateTask(int index, String newTask) {
    setState(() {
      tasks[index]['task'] = newTask;
    });
    saveTasks();
  }

  void deleteTask(int index) {
    setState(() {
      tasks.removeAt(index);
    });
    saveTasks();
  }

  // Display dialog to edit a task
  void showEditTaskDialog( index) {
    TextEditingController editController = TextEditingController(text: tasks[index]['task']);
    showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          backgroundColor: Colors.blueGrey,
          title: Text('Editing',style: TextStyle(color: Colors.white),),
          
          content: TextField(
            controller: editController,
            decoration: InputDecoration(
              
              hintText: 'Update your list',
              enabledBorder: OutlineInputBorder(
          borderSide: BorderSide(color: Colors.white, width: 2.0), // Normal border color
          borderRadius: BorderRadius.circular(8.0),
        ),
          
            border: OutlineInputBorder(
               
              borderRadius: BorderRadius.all(Radius.circular(20))
            
            ),
            ),
           
          ),
          actions: [
            TextButton(
              onPressed: () {
                updateTask(index, editController.text);
                Navigator.pop(context);
              },
              child: Text('Store',style: TextStyle(color: Colors.white),),
            ),
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: Text('exit',style: TextStyle(color: Colors.white),),
            ),
          ],
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        iconTheme: IconThemeData(color: Colors.white),
        backgroundColor: Colors.black38,
        title: Center(
          child: Text("TO DO APP",style: TextStyle(color: Colors.white,fontSize: 30,fontWeight:FontWeight.bold)),
        ),
      ),
      drawer: Drawer(),
      backgroundColor: Colors.blueAccent,
      body: Column(
        
        children: [
          Padding(
            padding: const EdgeInsets.all(50),
            child: Row(
              children: [
                Expanded(
                
                  child: Center(
                    child: TextField(
                     textAlign: TextAlign.center,
                    controller: taskController,
                    decoration: InputDecoration(
                      enabledBorder: OutlineInputBorder(
          borderSide: BorderSide(color: Colors.white, width: 2.0), // Normal border color
          borderRadius: BorderRadius.circular(8.0),
        ),
                      hintText: 'Enter a task',
                      hintStyle: TextStyle(color: Colors.white),
                      border: OutlineInputBorder(
                        
                        borderRadius: BorderRadius.all(Radius.circular(20))
                        
                      ),
                    ),
                  ),
                  )
                ),
                IconButton(
                  icon: Icon(Icons.add_box_outlined,color: Colors.white,),
                  iconSize: 30,
                   
                  onPressed: addTask,
                ),
              ],
            ),
          ),
          Expanded(
          
            child: ListView.builder(
              padding: EdgeInsets.only(
                top: 0,
                bottom: 10,
                left: 40,
                right: 40

              ),
              itemCount: tasks.length,
              itemBuilder: (context, index) {
                
                return Card(
                  
                  color: Colors.orange[50],
                  child: ListTile(
                    title: Text(
                      tasks[index]['task'],
                       
                    ),
                    leading: Checkbox(
                       activeColor: Colors.green,
                      value: tasks[index]['isCompleted'],
                      onChanged: (value) => toggleTaskCompletion(index),
                      
                        
                    ),
                    trailing: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        IconButton(
                          icon: Icon(Icons.edit, color: Colors.black),
                          onPressed: () => showEditTaskDialog(index),
                        ),
                        IconButton(
                          icon: Icon(Icons.delete, color: Colors.red),
                          onPressed: () => deleteTask(index),
                        ),
                      ],
                    ),
                  ),
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}


//Task 1

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
void main(){
  runApp(const MyApp());
}
class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return const MaterialApp(
      debugShowCheckedModeBanner: false,
      home: input(),
    );
  }
}
class input extends StatelessWidget {
  const input ({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Text Field",style: TextStyle(color: Colors.white),),
        backgroundColor: Colors.black,
        
      ),
    // backgroundColor: color.Colors.white,
    backgroundColor: Colors.white,
      body: Center(
        
        child: SizedBox(
          width: 300,
          
          
          
           child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
             children: [
               
               TextField(
                 inputFormatters: [
                  //  FilteringTextInputFormatter.allow(RegExp(r'[a-zA-Z]')),
                  FilteringTextInputFormatter.allow(RegExp(r'[a-zA-z]'))
                 ],
                 
                decoration: const InputDecoration(
                  
                     label: Text("UserName"),
                  hintText: "Jethanand" ,hintStyle: TextStyle(color: Colors.black38),
                  
               
                  focusedBorder:OutlineInputBorder(
                    
                    borderRadius: BorderRadius.all(Radius.circular(5)),
                    borderSide: BorderSide(
                       width: 2,
                      color: Colors.blue
                    )
                  ) ,
                  
                  border: OutlineInputBorder(
              
                    borderSide: BorderSide(
                      
                    ),
                    borderRadius: BorderRadius.all(
                      Radius.circular(10)
                      
                    )
                  ),
                  
                  prefixIcon: Icon(
                    Icons.person,
                    
            
                  )
                ),
                
              
                
              
               ),
               
               const SizedBox(height: 20,),
                 TextField(
                 inputFormatters: [
                  //  FilteringTextInputFormatter.allow(RegExp(r'[a-zA-Z]')),
                  FilteringTextInputFormatter.allow(RegExp(r'[a-zA-Z0-9@_.-]'))
                 ],
                 
                decoration: const InputDecoration(
                     label: Text("Email"),
                  hintText: "****@gmail.com" ,hintStyle: TextStyle(color: Colors.black38),
               
                  focusedBorder:OutlineInputBorder(
                    
                    borderRadius: BorderRadius.all(Radius.circular(5)),
                    borderSide: BorderSide(
                       width: 2,
                      color: Colors.blue
                    )
                  ) ,
                  border: OutlineInputBorder(
              
                    borderSide: BorderSide(
                      
                    ),
                    borderRadius: BorderRadius.all(
                      Radius.circular(10)
                      
                    )
                  ),
                  prefixIcon: Icon(
                    Icons.email,
                    
                  )
                ),
              
               ),
               
               const SizedBox(height: 20,),

                 TextField(
                  maxLength: 13,
                inputFormatters: [
                  FilteringTextInputFormatter.digitsOnly
                ],
                decoration: const InputDecoration(
                     label: Text("CNIC"),
                  hintText: "XXXXXXXXXXXXX" ,hintStyle: TextStyle(color: Colors.black38),
               
                  focusedBorder:OutlineInputBorder(
                    
                    borderRadius: BorderRadius.all(Radius.circular(5)),
                    borderSide: BorderSide(
                       width: 2,
                      color: Colors.blue
                    )
                  ) ,
                  border: OutlineInputBorder(
              
                    borderSide: BorderSide(
                      
                    ),
                    borderRadius: BorderRadius.all(
                      Radius.circular(10)
                      
                    )
                  ),
                  prefixIcon: Icon(
                   Icons.credit_card
                    
                  )
                ),
              
               ),
               
                 const SizedBox(height: 20,),

                  TextField(
                
                 maxLength: 11,
                inputFormatters: [
                  FilteringTextInputFormatter.digitsOnly
                ],
                decoration: const InputDecoration(
                     label: Text("Phone Number"),
                  hintText: "03XXXXXXXXX" ,hintStyle: TextStyle(color: Colors.black38),
               
                  focusedBorder:OutlineInputBorder(
                    
                    borderRadius: BorderRadius.all(Radius.circular(5)),
                    borderSide: BorderSide(
                       width: 2,
                      color: Colors.blue
                    )
                  ) ,
                  border: OutlineInputBorder(
              
                    borderSide: BorderSide(
                      
                    ),
                    borderRadius: BorderRadius.all(
                      Radius.circular(10)
                      
                    )
                  ),
                  prefixIcon: Icon(
                   Icons.call
                    
                  )
                ),
              
               ),

                 const SizedBox(height: 20,),

                 TextField(
                
                inputFormatters: [
                  FilteringTextInputFormatter.allow(RegExp(r'[a-zA-Z0-9_.-:]'))
                ],
                decoration: const InputDecoration(
                     label: Text("Address"),
                  hintText: "Plot no:XX" ,hintStyle: TextStyle(color: Colors.black38),
               
                  focusedBorder:OutlineInputBorder(
                    
                    borderRadius: BorderRadius.all(Radius.circular(5)),
                    borderSide: BorderSide(
                       width: 2,
                      color: Colors.blue
                    )
                  ) ,
                  border: OutlineInputBorder(
              
                    borderSide: BorderSide(
                      
                    ),
                    borderRadius: BorderRadius.all(
                      Radius.circular(10)
                      
                    )
                  ),
                  prefixIcon: Icon(
                   Icons.home
                    
                  )
                ),
              
               ),
               
                 const SizedBox(height: 20,),

                  TextField(
                    maxLength: 8,
                    inputFormatters: [
                      FilteringTextInputFormatter.allow(RegExp(r'[a-zA-Z0-9_.-@#$%^&*()+{}|\":?><!]'))
                    ],
                obscureText: true,
                
                obscuringCharacter: '*',
                decoration: const InputDecoration(
                  
                     label: Text("Password"),
                  hintText: "********" ,hintStyle: TextStyle(color: Colors.black38),
               
                  focusedBorder:OutlineInputBorder(
                    
                    borderRadius: BorderRadius.all(Radius.circular(5)),
                    borderSide: BorderSide(
                       width: 2,
                      color: Colors.blue
                    )
                  ) ,
                  border: OutlineInputBorder(
              
                    borderSide: BorderSide(
                      
                    ),
                    borderRadius: BorderRadius.all(
                      Radius.circular(10)
                      
                    )
                  ),
                  prefixIcon: Icon(
                   Icons.password
                    
                  )
                  
                ),
              
               ),
               

               
                 
             ],
           ),
        ),
        
      ),
       
    );
    
    
  }
}